        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h5 mb-0 text-gray-800"><i class="far fa-plus-square"></i> Tambah Order</h1>

            </div>
            <!-- Content Row -->
            <div class="row">
                <!-- Content Column -->
                <div class="col-lg-6 col-md-6 col-sm-6 mb-5">
                    <form>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="name_order" name="name_order" placeholder="Nama Lengkap...">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Alamat</label>
                            <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat Lengkap...">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">No Telephone</label>
                            <input type="text" class="form-control" id="telpon" name="telpon" placeholder="Telephone...">
                        </div>
                        <div class="form-group">
                            <label for="validationCustom04">Pilihan Paket</label>
                            <select class="custom-select" id="paket" name="paket" required>
                                <option selected disabled value="">---Pilih Paket---</option>
                                <option value="1P (Inet)">1P (Inet)</option>
                                <option value="2P (Inet + TV)">2P (Inet + TV)</option>
                                <option value="2P (Inet + Phone)">2P (Inet + Phone)</option>
                                <option value="3P">3P (Inet + Phone + TV</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email...">
                        </div>
                        <div class="form-group">
                            <label for="validationCustom05">ODP</label>
                            <select class="custom-select" id="zona_odp" name="zona_odp" required>
                                <option selected disabled value="">---Pilih ODP---</option>
                                <?php foreach ($get_odp as $row) : ?>
                                    <option value="<?php echo $row->zona_odp; ?>"> <?php echo $row->get_odp; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="validationCustom05">Nama Teknisi</label>
                            <select class="custom-select" id="zona_odp" name="zona_odp" required>
                                <option selected disabled value="">---Pilih TEKNISI---</option>
                                <?php foreach ($get_odp as $row) : ?>
                                    <option value="<?php echo $row->zona_odp; ?>"> <?php echo $row->get_odp; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-row">
                            <div class="col-md-5 mb-5">
                                <label for="validationCustom03">Date Take</label>
                                <input type="datetime-local" class="form-control" id="tanggal" name="tanggal">
                                <div class="invalid-feedback">Masukkan Tanggal yang Valid.</div>
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
            </div>
            <!-- Content Row -->



        </div>
        </div>
        </div>



        </div>
        <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->