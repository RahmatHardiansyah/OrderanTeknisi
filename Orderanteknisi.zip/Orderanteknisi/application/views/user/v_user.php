        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h5 mb-0 text-gray-800">Tambah User</h1>
            </div>
            <!-- Content Row -->
            <div class="row">
                <!-- Content Column -->
                <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
                    <table class="table table-bordered">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Akses</th>
                            <th>Password</th>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Rahmat Hardiansyah</td>
                            <td>ardi@gmail.com</td>
                            <td>Admin</td>
                            <td>********</td>
                        </tr>
                    </table>
                </div>
            </div>
            <!-- Content Row -->



        </div>
        </div>
        </div>



        </div>
        <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->