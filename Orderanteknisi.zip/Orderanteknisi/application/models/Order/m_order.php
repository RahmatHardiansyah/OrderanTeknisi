<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Order extends CI_Model
{
    public function get_odp()
    {
        $query = $this->db->get('SELECT * FROM odp ORDER BY zona_odp');
        return $query->result();
    }
}
