<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function index()
    {
        $this->load->view('tampilan/dash_header');
        $this->load->view('tampilan/sidebar');
        $this->load->view('tampilan/dashboard');
        $this->load->view('tampilan/dash_footer');
    }
}
