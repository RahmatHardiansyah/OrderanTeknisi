<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Order extends CI_Controller
{

    public function index()
    {
        $this->load->view('tampilan/dash_header');
        $this->load->view('tampilan/sidebar');
        $this->load->view('Order/v_order');
        $this->load->view('tampilan/dash_footer');
    }
}
